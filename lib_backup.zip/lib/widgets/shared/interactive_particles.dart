// import 'dart:math' as math;
// import 'package:flutter/material.dart';
// import 'package:flutter/scheduler.dart';

// final cursorNotifier = ValueNotifier<Offset>(const Offset(-9999, -9999));

// class InteractiveParticles extends StatefulWidget {
//   final int count;

//   const InteractiveParticles({
//     super.key,
//     this.count = 1000, // Very high count for a dense dot effect
//   });

//   @override
//   State<InteractiveParticles> createState() => _InteractiveParticlesState();
// }

// class _InteractiveParticlesState extends State<InteractiveParticles>
//     with SingleTickerProviderStateMixin {
//   late final Ticker _ticker;
//   final List<_Particle> particles = [];

//   Offset smoothCursor = const Offset(-9999, -9999);
//   Duration last = Duration.zero;
//   Size screenSize = Size.zero;
//   double time = 0;

//   @override
//   void initState() {
//     super.initState();
//     final rng = math.Random();
//     for (int i = 0; i < widget.count; i++) {
//       particles.add(_Particle(rng));
//     }
//     _ticker = createTicker(_tick)..start();
//   }

//   void _tick(Duration elapsed) {
//     if (screenSize == Size.zero) return;

//     final dt =
//         last == Duration.zero ? 0.016 : (elapsed - last).inMicroseconds / 1e6;
//     last = elapsed;
//     time += dt;

//     final raw = cursorNotifier.value;

//     if (raw.dx > -1000) {
//       smoothCursor = Offset.lerp(smoothCursor, raw, 0.15)!;
//     } else {
//       smoothCursor = Offset.lerp(
//         smoothCursor,
//         const Offset(-9999, -9999),
//         0.05,
//       )!;
//     }

//     for (final p in particles) {
//       p.update(dt, smoothCursor, screenSize, time);
//     }

//     setState(() {});
//   }

//   @override
//   void dispose() {
//     _ticker.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return LayoutBuilder(
//       builder: (context, constraints) {
//         final newSize = Size(constraints.maxWidth, constraints.maxHeight);
//         if (screenSize != newSize) {
//           screenSize = newSize;
//           for (final p in particles) {
//             if (!p.initialized) {
//               p.init(screenSize);
//             }
//           }
//         }

//         return CustomPaint(
//           painter: _Painter(
//             particles,
//             smoothCursor,
//             screenSize,
//             Theme.of(context).brightness == Brightness.dark,
//             time,
//           ),
//           child: const SizedBox.expand(),
//         );
//       },
//     );
//   }
// }

// // ───────────── PARTICLE ─────────────

// class _Particle {
//   double x = 0, y = 0;
//   double vx = 0, vy = 0;
//   double length = 0;
//   double thickness = 0;

//   bool initialized = false;
//   bool isShootingStar = false;
//   double shootingStarTime = 0;
//   final math.Random rng;

//   _Particle(this.rng);

//   void init(Size size) {
//     x = rng.nextDouble() * size.width;
//     y = rng.nextDouble() * size.height;

//     // Initial velocity
//     vx = (rng.nextDouble() - 0.5) * 20;
//     vy = (rng.nextDouble() - 0.5) * 20;

//     // Dots have varying sizes
//     thickness = 1.0 + rng.nextDouble() * 2.5; // Radius of the dot
//     initialized = true;
//   }

//   void update(double dt, Offset cursor, Size screen, double time) {
//     // Faster pseudo-random flow field to save trig calls
//     double angle =
//         (math.sin(x * 0.002 + time * 0.2) + math.cos(y * 0.002 + time * 0.2)) *
//             math.pi *
//             2;
//     double speedField = 35.0; // Fixed speed field saves more trig calls

//     double targetVx = math.cos(angle) * speedField;
//     double targetVy = math.sin(angle) * speedField;

//     // Mouse Attraction (Swarm effect)
//     final cursorActive = cursor.dx > -1000;
//     if (cursorActive) {
//       final dx = cursor.dx - x;
//       final dy = cursor.dy - y;
//       final dist = math.sqrt(dx * dx + dy * dy);

//       if (dist > 0.1) {
//         // Pull particles strongly towards the cursor
//         // The pull scales with distance so far particles catch up quickly
//         final pullStrength = (dist * 2.0).clamp(100.0, 800.0);
//         targetVx += (dx / dist) * pullStrength;
//         targetVy += (dy / dist) * pullStrength;

//         // Inner repulsion prevents them from all overlapping perfectly in the center
//         // Giving each particle a slightly different "orbit" based on its thickness
//         final orbitRadius = 30.0 + (thickness * 15.0);
//         if (dist < orbitRadius) {
//           final push = (orbitRadius - dist) / orbitRadius;
//           // Push away very strongly when too close
//           targetVx -= (dx / dist) * push * 1500;
//           targetVy -= (dy / dist) * push * 1500;
//         }
//       }
//     }

//     // Randomly turn into a shooting star for a quick burst of speed!
//     if (!isShootingStar && rng.nextDouble() < 0.0001) {
//       isShootingStar = true;
//       shootingStarTime = rng.nextDouble() * 1.5 + 0.5; // Lasts 0.5 to 2 seconds
//     }

//     if (isShootingStar) {
//       shootingStarTime -= dt;
//       if (shootingStarTime <= 0) {
//         isShootingStar = false;
//       }
//       // Massively speed up and shoot across the screen
//       targetVx = (vx > 0 ? 1 : -1) * 600.0;
//       targetVy = (vy > 0 ? 1 : -1) * 600.0;
//     }

//     // Smoothly adjust velocity to target
//     // Lower multiplier means more "inertia" / trailing when the cursor moves fast
//     final inertia = cursorActive ? 1.8 : 3.0;
//     vx += (targetVx - vx) * inertia * dt;
//     vy += (targetVy - vy) * inertia * dt;

//     // Update position
//     x += vx * dt;
//     y += vy * dt;

//     // Wrap around edges to create continuous flow
//     const margin = 50.0;
//     if (x < -margin)
//       x = screen.width + margin;
//     else if (x > screen.width + margin) x = -margin;

//     if (y < -margin)
//       y = screen.height + margin;
//     else if (y > screen.height + margin) y = -margin;
//   }
// }

// // ───────────── PAINTER ─────────────

// class _Painter extends CustomPainter {
//   final List<_Particle> particles;
//   final Offset cursor;
//   final Size screen;
//   final bool isDark;
//   final double time;

//   _Painter(this.particles, this.cursor, this.screen, this.isDark, this.time);

//   @override
//   void paint(Canvas canvas, Size size) {
//     // Theme-based base colors
//     final Color baseTL = isDark
//         ? const Color(0xFF00E5FF)
//         : const Color(0xFF0D47A1); // Cyan / Dark Blue
//     final Color baseTR = isDark
//         ? const Color(0xFFD500F9)
//         : const Color(0xFFE91E63); // Purple / Pink
//     final Color baseBL = isDark
//         ? const Color(0xFFD500F9)
//         : const Color(0xFFE91E63); // Purple / Pink
//     final Color baseBR = isDark
//         ? const Color(0xFF2962FF)
//         : const Color(0xFFFF6D00); // Blue / Orange

//     // Spatial Gradient Colors that slowly shift hue over time!
//     final Color colorTopLeft = HSVColor.fromColor(baseTL)
//         .withHue(
//             (HSVColor.fromColor(baseTL).hue + math.sin(time * 0.2) * 15) % 360)
//         .toColor();
//     final Color colorTopRight = HSVColor.fromColor(baseTR)
//         .withHue(
//             (HSVColor.fromColor(baseTR).hue + math.sin(time * 0.3) * 15) % 360)
//         .toColor();
//     final Color colorBottomLeft = HSVColor.fromColor(baseBL)
//         .withHue(
//             (HSVColor.fromColor(baseBL).hue + math.sin(time * 0.25) * 15) % 360)
//         .toColor();
//     final Color colorBottomRight = HSVColor.fromColor(baseBR)
//         .withHue(
//             (HSVColor.fromColor(baseBR).hue + math.sin(time * 0.4) * 15) % 360)
//         .toColor();

//     final cursorActive = cursor.dx > -1000;

//     // Draw the dot particles
//     for (final p in particles) {
//       // Determine color based on spatial position
//       final normX = (p.x / screen.width).clamp(0.0, 1.0);
//       final normY = (p.y / screen.height).clamp(0.0, 1.0);

//       Color topColor = Color.lerp(colorTopLeft, colorTopRight, normX)!;
//       Color bottomColor = Color.lerp(colorBottomLeft, colorBottomRight, normX)!;
//       Color finalColor = Color.lerp(topColor, bottomColor, normY)!;

//       // Organic twinkling/breathing effect
//       final pulse = 1.0 + 0.4 * math.sin(time * 3.0 + p.x * 0.02 + p.y * 0.02);
//       final currentRadius = (p.thickness * pulse).clamp(0.5, 6.0);

//       // Shooting stars leave a soft glowing trail blur
//       if (p.isShootingStar) {
//         canvas.drawCircle(
//           Offset(p.x, p.y),
//           currentRadius * 4.0,
//           Paint()
//             ..color = finalColor.withOpacity(0.3)
//             ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4.0),
//         );
//       }

//       // Draw the dot
//       canvas.drawCircle(
//         Offset(p.x, p.y),
//         currentRadius,
//         Paint()
//           ..color = finalColor
//           ..style = PaintingStyle.fill,
//       );
//     }

//     // Subtle cursor glow
//     if (cursorActive) {
//       canvas.drawCircle(
//         cursor,
//         15.0,
//         Paint()
//           ..color = (isDark ? Colors.white : Colors.black).withOpacity(0.05)
//           ..style = PaintingStyle.fill
//           ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10),
//       );
//     }
//   }

//   @override
//   bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
// }

//////////

import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import '../../core/theme/app_theme.dart';

// ─────────────────────────────────────────────────────────────────────────────
// Magnetic gather + burst particle system
//
// Behaviour:
//   • Idle          — particles drift slowly with sinusoidal motion
//   • Cursor still  — nearby particles are ATTRACTED toward cursor (gather)
//   • Cursor moves  — fast movement triggers a REPULSION BURST (spread)
//   • After burst   — particles spring back to their home positions smoothly
//
// Physics per particle:
//   attractForce  = strength * (1 - dist/radius)²   [toward cursor]
//   repelForce    = burstStrength * cursorSpeed * falloff  [away from cursor]
//   springForce   = stiffness * (home - pos)
//   velocity      = (velocity + forces * dt) * damping
// ─────────────────────────────────────────────────────────────────────────────

/// Global cursor position — written by HomeScreen's top-level MouseRegion.
final CursorNotifier globalCursor = CursorNotifier();

class CursorNotifier extends ValueNotifier<Offset> {
  CursorNotifier() : super(const Offset(-9999, -9999));
}

// ─────────────────────────────────────────────────────────────────────────────
// Widget
// ─────────────────────────────────────────────────────────────────────────────

class InteractiveParticles extends StatefulWidget {
  final int count;
  final Color color;
  final Color accentColor;

  const InteractiveParticles({
    super.key,
    this.count = 1150,
    this.color = AppColors.neonBlue,
    this.accentColor = AppColors.neonBlue,
  });

  @override
  State<InteractiveParticles> createState() => _InteractiveParticlesState();
}

class _InteractiveParticlesState extends State<InteractiveParticles>
    with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  late final List<_Particle> _particles;
  late final _RepaintNotifier _repaintNotifier;
  late _ParticlesPainter _painter;

  Duration _lastTime = Duration.zero;

  // Cursor velocity tracking
  Offset _prevCursor = const Offset(-9999, -9999);
  double _cursorSpeed = 0; // px/s
  double _burstEnergy = 0; // 0..1, decays over time

  @override
  void initState() {
    super.initState();
    final rng = math.Random(99991);
    _particles = List.generate(widget.count, (i) => _Particle.random(rng, i));
    _repaintNotifier = _RepaintNotifier();
    _painter = _ParticlesPainter(
      particles: _particles,
      color: widget.color,
      accentColor: widget.accentColor,
      repaint: _repaintNotifier,
    );
    _ticker = createTicker(_onTick)..start();
  }

  void _onTick(Duration elapsed) {
    final dt = _lastTime == Duration.zero
        ? 0.016
        : (elapsed - _lastTime).inMicroseconds / 1000000.0;
    _lastTime = elapsed;
    final safeDt = dt.clamp(0.0, 0.05);

    final size = _painter.lastSize;
    if (size == Size.zero) return;

    final cursor = globalCursor.value;
    final cursorActive = cursor.dx > -1000;

    // ── Cursor velocity ───────────────────────────────────────────────────
    if (cursorActive && _prevCursor.dx > -1000 && safeDt > 0) {
      final ddx = cursor.dx - _prevCursor.dx;
      final ddy = cursor.dy - _prevCursor.dy;
      final rawSpeed = math.sqrt(ddx * ddx + ddy * ddy) / safeDt;
      // Smooth speed with exponential moving average
      _cursorSpeed = _cursorSpeed * 0.6 + rawSpeed * 0.4;
    } else if (!cursorActive) {
      _cursorSpeed = 0;
    }
    _prevCursor = cursor;

    // ── Burst energy: spikes on fast movement, decays to 0 ───────────────
    // Threshold: > 400 px/s counts as "fast"
    const speedThreshold = 400.0;
    if (_cursorSpeed > speedThreshold) {
      final spike = ((_cursorSpeed - speedThreshold) / 800.0).clamp(0.0, 1.0);
      _burstEnergy = (_burstEnergy + spike * 0.6).clamp(0.0, 1.0);
    }
    // Decay burst energy over ~0.5s
    _burstEnergy = (_burstEnergy - safeDt * 2.2).clamp(0.0, 1.0);

    // ── Update particles ──────────────────────────────────────────────────
    for (final p in _particles) {
      p.update(safeDt, cursor, size, _burstEnergy, cursorActive);
    }

    _painter
      ..cursor = cursor
      ..elapsed = elapsed.inMilliseconds / 1000.0
      ..burstEnergy = _burstEnergy
      ..cursorSpeed = _cursorSpeed;

    _repaintNotifier.notify();
  }

  @override
  void didUpdateWidget(InteractiveParticles old) {
    super.didUpdateWidget(old);
    if (old.color != widget.color || old.accentColor != widget.accentColor) {
      _painter = _ParticlesPainter(
        particles: _particles,
        color: widget.color,
        accentColor: widget.accentColor,
        repaint: _repaintNotifier,
      );
    }
  }

  @override
  void dispose() {
    _ticker.dispose();
    _repaintNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: CustomPaint(
        painter: _painter,
        child: const SizedBox.expand(),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Repaint trigger
// ─────────────────────────────────────────────────────────────────────────────

class _RepaintNotifier extends ChangeNotifier {
  void notify() => notifyListeners();
}

// ─────────────────────────────────────────────────────────────────────────────
// Physics constants
// ─────────────────────────────────────────────────────────────────────────────

const double _kRadius = 180.0; // cursor influence radius (px)
const double _kAttractStr = 12000.0; // attraction force when cursor is still
const double _kBurstStr = 35000.0; // repulsion force on fast cursor move
const double _kSpringK = 3.8; // spring stiffness back to home
const double _kDamping = 0.78; // velocity damping (per frame)
const double _kGatherRadius = 55.0; // particles cluster within this radius

// ─────────────────────────────────────────────────────────────────────────────
// Particle
// ─────────────────────────────────────────────────────────────────────────────

class _Particle {
  final double homeX, homeY; // normalised (0..1)
  final double driftAmp;
  final double freqX, freqY;
  final double phaseX, phaseY;
  final double baseSize;
  final double baseOpacity;
  final bool isStar;

  double x = -1, y = -1;
  double vx = 0, vy = 0;

  _Particle({
    required this.homeX,
    required this.homeY,
    required this.driftAmp,
    required this.freqX,
    required this.freqY,
    required this.phaseX,
    required this.phaseY,
    required this.baseSize,
    required this.baseOpacity,
    required this.isStar,
  });

  factory _Particle.random(math.Random rng, int i) => _Particle(
        homeX: rng.nextDouble(),
        homeY: rng.nextDouble(),
        driftAmp: rng.nextDouble() * 18 + 6,
        freqX: rng.nextDouble() * 0.30 + 0.06,
        freqY: rng.nextDouble() * 0.30 + 0.06,
        phaseX: rng.nextDouble() * math.pi * 2,
        phaseY: rng.nextDouble() * math.pi * 2,
        baseSize: rng.nextDouble() * 2.4 + 0.9,
        baseOpacity: rng.nextDouble() * 0.38 + 0.10,
        isStar: rng.nextDouble() < 0.20,
      );

  void update(
    double dt,
    Offset cursor,
    Size size,
    double burstEnergy,
    bool cursorActive,
  ) {
    // ── Drifting home target ──────────────────────────────────────────────
    final t = DateTime.now().millisecondsSinceEpoch / 1000.0;
    final tx = homeX * size.width + math.sin(t * freqX + phaseX) * driftAmp;
    final ty = homeY * size.height + math.cos(t * freqY + phaseY) * driftAmp;

    // Initialise position on first frame
    if (x < 0) {
      x = tx;
      y = ty;
      return;
    }

    // ── Spring force toward drifting home ────────────────────────────────
    final springFx = (tx - x) * _kSpringK;
    final springFy = (ty - y) * _kSpringK;

    // ── Cursor interaction ────────────────────────────────────────────────
    double cfx = 0, cfy = 0;

    if (cursorActive) {
      final dx = x - cursor.dx;
      final dy = y - cursor.dy;
      final dist2 = dx * dx + dy * dy;
      final dist = math.sqrt(dist2);

      if (dist < _kRadius && dist > 0.5) {
        final falloff = 1.0 - dist / _kRadius; // 1 at cursor, 0 at edge
        final falloff2 = falloff * falloff;

        if (burstEnergy > 0.05) {
          // ── BURST MODE: repel outward ─────────────────────────────────
          final strength = _kBurstStr * burstEnergy * falloff2 / dist;
          cfx = dx * strength;
          cfy = dy * strength;
        } else {
          // ── GATHER MODE: attract toward cursor ────────────────────────
          // Pull toward a ring at _kGatherRadius so particles orbit
          // rather than collapsing to a single point
          final pullDist = dist - _kGatherRadius;
          if (pullDist > 0) {
            final strength = _kAttractStr * falloff2 / dist;
            cfx = -(dx / dist) * strength; // toward cursor
            cfy = -(dy / dist) * strength;
          }
        }
      }
    }

    // ── Integrate ─────────────────────────────────────────────────────────
    vx = (vx + (springFx + cfx) * dt) * _kDamping;
    vy = (vy + (springFy + cfy) * dt) * _kDamping;
    x += vx * dt;
    y += vy * dt;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Painter
// ─────────────────────────────────────────────────────────────────────────────

class _ParticlesPainter extends CustomPainter {
  final List<_Particle> _particles;
  final Color color;
  final Color accentColor;

  Offset cursor = const Offset(-9999, -9999);
  double elapsed = 0;
  double burstEnergy = 0;
  double cursorSpeed = 0;
  Size lastSize = Size.zero;

  _ParticlesPainter({
    required List<_Particle> particles,
    required this.color,
    required this.accentColor,
    required Listenable repaint,
  })  : _particles = particles,
        super(repaint: repaint);

  @override
  bool shouldRepaint(_ParticlesPainter old) => false;

  @override
  void paint(Canvas canvas, Size size) {
    lastSize = size;
    final cursorActive = cursor.dx > -1000;

    // ── Cursor glow ───────────────────────────────────────────────────────
    if (cursorActive) _drawCursorGlow(canvas);

    // ── Particles ─────────────────────────────────────────────────────────
    for (final p in _particles) {
      if (p.x < 0) continue;

      final dx = p.x - cursor.dx;
      final dy = p.y - cursor.dy;
      final dist = math.sqrt(dx * dx + dy * dy);

      // Proximity: 1 at cursor, 0 at radius edge
      final proximity =
          cursorActive ? (1.0 - dist / _kRadius).clamp(0.0, 1.0) : 0.0;

      // Burst makes particles brighter and bigger
      final burstBoost = burstEnergy * proximity;
      final alpha =
          (p.baseOpacity + proximity * 0.5 + burstBoost * 0.3).clamp(0.0, 1.0);
      final radius = p.baseSize + proximity * 2.5 + burstBoost * 3.0;
      final pulse = 0.88 + 0.12 * math.sin(elapsed * 1.6 + p.phaseX);

      // Colour shifts toward accent when gathered, white-hot on burst
      final Color c;
      if (burstBoost > 0.3) {
        c = Color.lerp(accentColor, Colors.white, burstBoost * 0.4)!;
      } else if (proximity > 0.05) {
        c = Color.lerp(color, accentColor, proximity * 0.7)!;
      } else {
        c = color;
      }

      final paintColor = c.withValues(alpha: alpha * pulse);

      if (p.isStar) {
        _drawSparkle(canvas, Offset(p.x, p.y), radius * 1.5, paintColor);
      } else {
        _drawGlowDot(canvas, Offset(p.x, p.y), radius, paintColor, proximity);
      }
    }
  }

  void _drawGlowDot(
      Canvas canvas, Offset pos, double r, Color c, double bloom) {
    if (bloom > 0.08) {
      canvas.drawCircle(
        pos,
        r * 4.5,
        Paint()
          ..shader = RadialGradient(colors: [
            c.withValues(alpha: c.a * 0.20 * bloom),
            c.withValues(alpha: 0),
          ]).createShader(Rect.fromCircle(center: pos, radius: r * 4.5))
          ..style = PaintingStyle.fill,
      );
    }
    canvas.drawCircle(
      pos,
      r,
      Paint()
        ..color = c
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, r * 0.85)
        ..style = PaintingStyle.fill,
    );
    canvas.drawCircle(
      pos,
      r * 0.36,
      Paint()
        ..color = Colors.white.withValues(alpha: c.a * 0.5)
        ..style = PaintingStyle.fill,
    );
  }

  void _drawSparkle(Canvas canvas, Offset pos, double size, Color c) {
    final path = Path();
    const arms = 4;
    for (int i = 0; i < arms * 2; i++) {
      final angle = (i * math.pi / arms) - math.pi / 2;
      final r = i.isEven ? size : size * 0.30;
      final px = pos.dx + r * math.cos(angle);
      final py = pos.dy + r * math.sin(angle);
      i == 0 ? path.moveTo(px, py) : path.lineTo(px, py);
    }
    path.close();
    canvas.drawPath(
      path,
      Paint()
        ..color = c
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, size * 0.4)
        ..style = PaintingStyle.fill,
    );
    canvas.drawCircle(
      pos,
      size * 0.20,
      Paint()..color = Colors.white.withValues(alpha: c.a * 0.8),
    );
  }

  void _drawCursorGlow(Canvas canvas) {
    // Burst ring — expands and fades when burstEnergy > 0
    if (burstEnergy > 0.05) {
      final burstR = _kRadius * (0.3 + burstEnergy * 0.7);
      canvas.drawCircle(
        cursor,
        burstR,
        Paint()
          ..color = accentColor.withValues(alpha: burstEnergy * 0.18)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5 + burstEnergy * 2.0
          ..maskFilter =
              MaskFilter.blur(BlurStyle.normal, 8 + burstEnergy * 12),
      );
    }

    // Gather halo — glows when cursor is still
    final gatherGlow = (1.0 - burstEnergy).clamp(0.0, 1.0);
    canvas.drawCircle(
      cursor,
      _kRadius,
      Paint()
        ..shader = RadialGradient(
          colors: [
            color.withValues(alpha: 0.10 * gatherGlow),
            accentColor.withValues(alpha: 0.05 * gatherGlow),
            color.withValues(alpha: 0),
          ],
          stops: const [0.0, 0.5, 1.0],
        ).createShader(Rect.fromCircle(center: cursor, radius: _kRadius))
        ..style = PaintingStyle.fill,
    );

    // Pulsing inner ring
    final ringR = _kRadius * 0.28 * (0.88 + 0.12 * math.sin(elapsed * 3.5));
    canvas.drawCircle(
      cursor,
      ringR,
      Paint()
        ..color = color.withValues(
            alpha: (0.30 + 0.12 * math.sin(elapsed * 3.5)) * gatherGlow)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.5),
    );

    // Bright dot at cursor tip
    canvas.drawCircle(
      cursor,
      4.5,
      Paint()
        ..color = color.withValues(alpha: 0.70)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5)
        ..style = PaintingStyle.fill,
    );
  }
}
