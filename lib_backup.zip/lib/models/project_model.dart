import 'package:cloud_firestore/cloud_firestore.dart';

/// Model representing a portfolio project from Firestore
class ProjectModel {
  final String id;
  final String title;
  final String description;
  final List<String> tags;
  final String imageUrl;
  final String liveUrl;
  final String category;
  final int order;
  final DateTime createdAt;

  const ProjectModel({
    required this.id,
    required this.title,
    required this.description,
    required this.tags,
    required this.imageUrl,
    required this.liveUrl,
    required this.category,
    this.order = 0,
    required this.createdAt,
  });

  /// Create from Firestore document
  factory ProjectModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return ProjectModel(
      id: doc.id,
      title: data['title'] ?? '',
      description: data['description'] ?? '',
      tags: List<String>.from(data['tags'] ?? []),
      imageUrl: data['imageUrl'] ?? '',
      liveUrl: data['liveUrl'] ?? '',
      category: data['category'] ?? 'Mobile',
      order: data['order'] ?? 0,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  /// Convert to Firestore map
  Map<String, dynamic> toFirestore() {
    return {
      'title': title,
      'description': description,
      'tags': tags,
      'imageUrl': imageUrl,
      'liveUrl': liveUrl,
      'category': category,
      'order': order,
      'createdAt': Timestamp.fromDate(createdAt),
    };
  }

  /// Copy with modifications
  ProjectModel copyWith({
    String? id,
    String? title,
    String? description,
    List<String>? tags,
    String? imageUrl,
    String? liveUrl,
    String? category,
    int? order,
    DateTime? createdAt,
  }) {
    return ProjectModel(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      tags: tags ?? this.tags,
      imageUrl: imageUrl ?? this.imageUrl,
      liveUrl: liveUrl ?? this.liveUrl,
      category: category ?? this.category,
      order: order ?? this.order,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  String toString() => 'ProjectModel(id: $id, title: $title)';
}

/// Sample/fallback projects when Firebase is not configured
// List<ProjectModel> get sampleProjects => [
//       ProjectModel(
//         id: '1',
//         title: 'E-Commerce Flutter App',
//         description:
//             'A full-featured e-commerce app with Firebase backend, real-time inventory, payment integration, and beautiful UI animations.',
//         tags: ['Flutter', 'Firebase', 'Stripe', 'Provider'],
//         imageUrl: 'https://picsum.photos/seed/ecommerce/800/500',
//         liveUrl: 'https://github.com/akashkumar',
//         category: 'Mobile',
//         order: 1,
//         createdAt: DateTime(2024, 1, 15),
//       ),
//       ProjectModel(
//         id: '2',
//         title: 'Portfolio Web App',
//         description:
//             'This very portfolio! Built with Flutter Web, featuring glassmorphism UI, smooth animations, and Firebase integration.',
//         tags: ['Flutter Web', 'Firebase', 'Animations', 'Responsive'],
//         imageUrl: 'https://picsum.photos/seed/portfolio/800/500',
//         liveUrl: 'https://akashkumar.dev',
//         category: 'Web',
//         order: 2,
//         createdAt: DateTime(2024, 3, 10),
//       ),
//       ProjectModel(
//         id: '3',
//         title: 'Real-Time Chat App',
//         description:
//             'WhatsApp-like chat application with Firebase Realtime Database, push notifications, media sharing, and end-to-end encryption.',
//         tags: ['Flutter', 'Firebase', 'FCM', 'Encryption'],
//         imageUrl: 'https://picsum.photos/seed/chat/800/500',
//         liveUrl: 'https://github.com/akashkumar',
//         category: 'Firebase',
//         order: 3,
//         createdAt: DateTime(2023, 11, 5),
//       ),
//       ProjectModel(
//         id: '4',
//         title: 'Task Management Dashboard',
//         description:
//             'Kanban-style project management tool with drag-and-drop, team collaboration, analytics dashboard, and cloud sync.',
//         tags: ['Flutter Web', 'Riverpod', 'REST API', 'Charts'],
//         imageUrl: 'https://picsum.photos/seed/tasks/800/500',
//         liveUrl: 'https://github.com/akashkumar',
//         category: 'Web',
//         order: 4,
//         createdAt: DateTime(2023, 8, 20),
//       ),
//       ProjectModel(
//         id: '5',
//         title: 'Fitness Tracker App',
//         description:
//             'Health and fitness tracking app with workout plans, nutrition logging, progress charts, and wearable device integration.',
//         tags: ['Flutter', 'Health API', 'Charts', 'BLoC'],
//         imageUrl: 'https://picsum.photos/seed/fitness/800/500',
//         liveUrl: 'https://github.com/akashkumar',
//         category: 'Mobile',
//         order: 5,
//         createdAt: DateTime(2023, 6, 12),
//       ),
//       ProjectModel(
//         id: '6',
//         title: 'UI Component Library',
//         description:
//             'A comprehensive Flutter UI kit with 50+ custom widgets, glassmorphism components, animations, and dark/light themes.',
//         tags: ['Flutter', 'UI Kit', 'Animations', 'Open Source'],
//         imageUrl: 'https://picsum.photos/seed/uikit/800/500',
//         liveUrl: 'https://github.com/akashkumar',
//         category: 'UI/UX',
//         order: 6,
//         createdAt: DateTime(2023, 4, 1),
//       ),
//     ];

List<ProjectModel> get sampleProjects => [
      ProjectModel(
        id: '1',
        title: 'Acclaim Guard Services',
        description:
            'A US-based vehicle number plate scanner app with real-time detection and API integration. Implemented OCR-based scanning and optimized performance for accurate results.',
        tags: ['Flutter', 'OCR', 'Firebase', 'REST APIs'],
        imageUrl: 'https://picsum.photos/seed/acclaim/800/500',
        liveUrl: 'https://github.com/akashkumar',
        category: 'Mobile',
        order: 1,
        createdAt: DateTime(2023, 9, 10),
      ),
      ProjectModel(
        id: '2',
        title: 'Vitamein Healthcare App',
        description:
            'A healthcare mobile application focused on user wellness tracking and health management. Designed user-friendly UI with smooth navigation and API-based data handling.',
        tags: ['Flutter', 'Firebase', 'REST APIs', 'UI/UX'],
        imageUrl: 'https://picsum.photos/seed/vitamein/800/500',
        liveUrl: 'https://github.com/akashkumar',
        category: 'Mobile',
        order: 2,
        createdAt: DateTime(2023, 7, 5),
      ),
      ProjectModel(
        id: '3',
        title: 'Dr. Ortho E-commerce App',
        description:
            'An e-commerce mobile application for healthcare products with cart management, product listings, and secure checkout flow.',
        tags: ['Flutter', 'Firebase', 'Provider', 'E-commerce'],
        imageUrl: 'https://picsum.photos/seed/ortho/800/500',
        liveUrl:
            'https://play.google.com/store/apps/details?id=com.dr.ortho.drortho&pcampaignid=web_share',
        category: 'Mobile',
        order: 3,
        createdAt: DateTime(2023, 5, 15),
      ),
      ProjectModel(
        id: '4',
        title: 'Count Safety First (CSF)',
        description:
            'A road safety awareness application that allows users to report and track safety-related incidents. Focused on intuitive UI and real-time data updates.',
        tags: ['Flutter', 'Firebase', 'Maps', 'Realtime Data'],
        imageUrl: 'https://picsum.photos/seed/csf/800/500',
        liveUrl: 'https://github.com/akashkumar',
        category: 'Mobile',
        order: 4,
        createdAt: DateTime(2023, 3, 20),
      ),
      ProjectModel(
        id: '5',
        title: 'Dubai Local',
        description:
            'A live business listing application for Dubai featuring categorized listings, search functionality, and location-based services.',
        tags: ['Flutter', 'REST APIs', 'Search', 'Location'],
        imageUrl: 'https://picsum.photos/seed/dubai/800/500',
        liveUrl: 'https://github.com/akashkumar',
        category: 'Mobile',
        order: 5,
        createdAt: DateTime(2023, 1, 25),
      ),
      ProjectModel(
        id: '6',
        title: 'RedBus Clone',
        description:
            'A travel booking application with bus search, seat selection, and booking features. Built to understand complex UI flows and API integrations.',
        tags: ['Flutter', 'API Integration', 'UI/UX', 'Booking System'],
        imageUrl: 'https://picsum.photos/seed/redbus/800/500',
        liveUrl: 'https://github.com/akashkumar',
        category: 'Mobile',
        order: 6,
        createdAt: DateTime(2022, 11, 10),
      ),
    ];
